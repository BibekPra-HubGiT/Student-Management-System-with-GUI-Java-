
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Student
{

    //initalization variables
    private int enrollmentID;
    private String dateOfBirth;
    private String courseName;
    private String studentName;
    private String dateOfEnrollement;
    private int courseDuration;
    private int tuitionFee;
    public Student(String dateOfBirth,int courseDuration,String studentName, int tuitionFee)
    {
        this.dateOfBirth=dateOfBirth;
        this.studentName=studentName;
        this.courseDuration=courseDuration;
        this.tuitionFee=tuitionFee;
        this.courseName=" ";
        this.dateOfEnrollement=" ";
        this.enrollmentID=0; 
    }
    //accessor method is also called getter method.
    public int getenrollmentID()
    {
        return this.enrollmentID;
    }

    public String getdateOfBirth()
    {
        return this.dateOfBirth;
    }

    public String getcourseName()
    {
        return this.courseName;
    }

    public String getstudentName()
    {
        return this.studentName;
    }

    public String getdateOfEnrollement()
    {
        return this.dateOfEnrollement;
    }

    public int getcourseDuration()
    {
        return this.courseDuration;
    }

    public int gettuitionFee()
    {
        return this.tuitionFee;
    }
    //mutator method to set
    public void setcourseName(String courseName)
    {
        this.courseName=courseName;
    }

    public void setenrollmentID(int enrollmentID)
    {
        this.enrollmentID=enrollmentID;
    }

    public void setdateOfEnrollement(String dateOfEnrollement)
    {
        this.dateOfEnrollement=dateOfEnrollement;
    }

    public void setdateOfBirth(String dateOfBirth)
    {
        this.dateOfBirth=dateOfBirth;
    }

    public void setstudentName(String studentName)
    {
        this.studentName=studentName;
    }

    public void setcourseDuration(int courseDuration)
    {
        this.courseDuration=courseDuration;
    }

    public void settuitionFee(int tuitionFee)
    {
        this.tuitionFee=tuitionFee;
    }
    // display method
    public void display()
    {
        if(this.enrollmentID==0||this.dateOfBirth==" "||this.courseName==" "||this.studentName=="")
        {
            System.out.println("Please fill-up all parameters");
        }
        else
        {
            System.out.println("Your enrollmentID"+this.getenrollmentID());
            System.out.println("Your dateOfBirth" +this.getdateOfBirth());
            System.out.println("Your courseName" +this.getcourseName());
            System.out.println("StudentName is" +this.getstudentName());
            System.out.println("YearsEnrolled is" +this.getdateOfEnrollement());
            System.out.println("Your courseDuration" +this.getcourseDuration());
            System.out.println("Your tuitionFee" +this.gettuitionFee());
        }
    }

}
