import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import java.awt.Font;
import java.awt.*;
import javax.swing.JButton;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Write a description of class StudentGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class StudentGUI implements ActionListener
{
    private JFrame Checkout_Frame;
    private JPanel RegularGUIPanel,RegularGUIPanel1 ;
    private JPanel DropoutGUIPanel,DropoutGUIPanel1;
    private int courseDuration,tuitionFee,numOfRemainingModules,numOfMonthsAttended,enrollmentID,numOfCreditHours,numOfModules, remainingAmount;
    private String dateOfBirth,studentName,dateOfDropout,courseName,dateOfEnrollement;
    private double daysPresent;
    private JLabel CheckoutLabel, studentNameLabel,  enrollmentIDLabel, courseNameLabel, courseDurationLabel, tuitionFeeLabel, numOfModulesLable, numOfCreditHoursLabel, daysPresentLabel, numOfRemainingModulesLabel, numOfMonthsAttendedLabel,
    remainingAmountLabel, dateOfBirthLabel, dateOfEnrollementLabel, dateOfDropoutLabel; 
    private JTextField studentNameText, enrollmentIDText, courseNameText, courseDurationText, tuitionFeeText, numOfModulesText, numOfCreditHoursText, daysPresentText;
    private JTextField  studentNameText1, enrollmentIDText1, courseNameText1 , courseDurationText1, tuitionFeeText1, numOfRemainingModulesText1, numOfMonthsAttendedText1, remainingAmountText1;
    private JComboBox<String> dateOfBirthComboBox,dateOfEnrollementComboBox;
    private JComboBox<String> dateOfBirthComboBox1,dateOfEnrollementComboBox1,dateOfDropoutComboBox1;
    private JButton AddRegular, presentPercentageButton,grantCertificateButton, DisplayButton,EraseButton;
    private JButton AddDropout, billsPayableButton, RemoveButton,DisplayButton1,EraseButton1;
    private ArrayList<Student> StudentList=new ArrayList<>();
    public StudentGUI()
    {
        Checkout_Frame = new JFrame ("Checkout Form");
        Checkout_Frame.setSize(1200, 900);
        //JLabel colorfulLabel = new JLabel(); 
        Checkout_Frame.setResizable(false);

        // Regular panel 1 containing title 
        RegularGUIPanel1=new JPanel();
        RegularGUIPanel1.setLayout(null);
        RegularGUIPanel1.setBackground(new Color(0,0,0,70));
        RegularGUIPanel1.setBounds(0,0,1500,80);
        Checkout_Frame.add(RegularGUIPanel1);
        RegularGUIPanel1.setVisible(false);

        //overlay jlabel for text Regular_Form()
        JLabel RegularLabel=new JLabel("Regular_Form");
        RegularLabel.setForeground(Color.BLACK);
        RegularLabel.setBounds(459,25,500,40);
        RegularLabel.setFont(new Font("ui-monospaced",Font.BOLD,30));
        RegularGUIPanel1.add(RegularLabel);

        //regular panel

        RegularGUIPanel=new JPanel();
        RegularGUIPanel.setLayout(null);
        RegularGUIPanel.setBackground(Color.ORANGE);

        //All the Attributes of RegularGUIPanel
        enrollmentIDLabel = new JLabel("Enrollment ID:");
        enrollmentIDLabel.setBounds(160, 150, 150, 40);
        RegularGUIPanel.add(enrollmentIDLabel);
        enrollmentIDLabel.setForeground(Color.BLACK);
        enrollmentIDLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        enrollmentIDText = new JTextField();
        enrollmentIDText.setBounds(350, 150, 200, 40);
        RegularGUIPanel.add(enrollmentIDText);
        enrollmentIDText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        courseNameLabel = new JLabel("Course Name:");
        courseNameLabel.setBounds(630, 150, 150, 40);
        RegularGUIPanel.add(courseNameLabel);
        courseNameLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        courseNameText = new JTextField();
        courseNameText.setBounds(800, 150, 200, 40);
        RegularGUIPanel.add(courseNameText);
        courseNameText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        studentNameLabel = new JLabel("Student Name:");
        studentNameLabel.setBounds(160, 200, 150, 40);
        RegularGUIPanel.add(studentNameLabel);
        studentNameLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        studentNameText = new JTextField();
        studentNameText.setBounds(350, 200, 200, 40);
        RegularGUIPanel.add(studentNameText);
        studentNameText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        dateOfBirthLabel = new JLabel("Date Of Birth:");
        dateOfBirthLabel.setBounds(630, 200, 150, 40);
        RegularGUIPanel.add(dateOfBirthLabel);
        dateOfBirthLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        dateOfBirthComboBox=new JComboBox<>();
        for(int i=1990; i< 2025; i++ )
        {
            dateOfBirthComboBox.addItem(String.valueOf(i));            
        }
        dateOfBirthComboBox.setBounds(800, 200, 200, 40);
        RegularGUIPanel.add(dateOfBirthComboBox);
        dateOfBirthComboBox.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        dateOfEnrollementLabel = new JLabel("Date Of Enrollement:");
        dateOfEnrollementLabel.setBounds(160, 250, 170, 40);
        RegularGUIPanel.add(dateOfEnrollementLabel);
        dateOfEnrollementLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        dateOfEnrollementComboBox = new JComboBox<>();
        for(int i=1995; i< 2025; i++)
        {
            dateOfEnrollementComboBox.addItem(String.valueOf(i));
        }
        dateOfEnrollementComboBox.setBounds(350, 250, 200, 40);
        RegularGUIPanel.add(dateOfEnrollementComboBox);
        dateOfEnrollementComboBox.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        courseDurationLabel = new JLabel("Course Duration:");
        courseDurationLabel.setBounds(630, 250, 150, 40);
        RegularGUIPanel.add(courseDurationLabel);
        courseDurationLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        courseDurationText = new JTextField();
        courseDurationText.setBounds(800, 250, 200, 40);
        RegularGUIPanel.add(courseDurationText);
        courseDurationText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        tuitionFeeLabel = new JLabel("Tuition Fee:");
        tuitionFeeLabel.setBounds(160, 300, 150, 40);
        RegularGUIPanel.add(tuitionFeeLabel);
        tuitionFeeLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        tuitionFeeText = new JTextField();
        tuitionFeeText.setBounds(350, 300, 200, 40);
        RegularGUIPanel.add(tuitionFeeText);
        tuitionFeeText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        numOfModulesLable = new JLabel("Num. Of Modules:");
        numOfModulesLable.setBounds(630, 300, 150, 40);
        RegularGUIPanel.add(numOfModulesLable);
        numOfModulesLable.setFont(new Font("ui-monospaced",Font.BOLD,15));

        numOfModulesText = new JTextField();
        numOfModulesText.setBounds(800, 300, 200, 40);
        RegularGUIPanel.add(numOfModulesText);
        numOfModulesText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        numOfCreditHoursLabel = new JLabel("Num. Of Credit Hours:");
        numOfCreditHoursLabel.setBounds(160, 350, 165, 40);
        RegularGUIPanel.add(numOfCreditHoursLabel);
        numOfCreditHoursLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        numOfCreditHoursText = new JTextField();
        numOfCreditHoursText.setBounds(350, 350, 200, 40);
        RegularGUIPanel.add(numOfCreditHoursText);
        numOfCreditHoursText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        daysPresentLabel = new JLabel("Days Present:");
        daysPresentLabel.setBounds(630, 350, 150, 40);
        RegularGUIPanel.add(daysPresentLabel);
        daysPresentLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        daysPresentText= new JTextField();
        daysPresentText.setBounds(800, 350, 200, 40);
        RegularGUIPanel.add(daysPresentText);
        daysPresentText.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        //Button//////
        AddRegular=new JButton("Add an Object of Regular");
        AddRegular.setBounds(350, 450, 450, 50);
        //AddDropout.setForeground(Color.BLACK);
        RegularGUIPanel.add(AddRegular);
        AddRegular.setFont(new Font("ui-monospaced",Font.BOLD,18));
        AddRegular.addActionListener(this);

        presentPercentageButton=new JButton("Present Percentage");
        presentPercentageButton.setBounds(170, 530, 160, 50);
        //AddDropout.setForeground(Color.BLACK);
        RegularGUIPanel.add(presentPercentageButton);
        presentPercentageButton.setFont(new Font("ui-monospaced",Font.BOLD,15));
        presentPercentageButton.addActionListener(this);

        grantCertificateButton=new JButton("Grant Certificate");
        grantCertificateButton.setBounds(350, 530, 190, 50);
        //AddDropout.setForeground(Color.BLACK);
        RegularGUIPanel.add(grantCertificateButton);
        grantCertificateButton.setFont(new Font("ui-monospaced",Font.BOLD,15));
        grantCertificateButton.addActionListener(this);

        DisplayButton=new JButton("Display");
        DisplayButton.setBounds(590, 530, 190, 50);
        //AddDropout.setForeground(Color.BLACK);
        RegularGUIPanel.add(DisplayButton);
        DisplayButton.setFont(new Font("ui-monospaced",Font.BOLD,15));
        DisplayButton.addActionListener(this);

        EraseButton=new JButton("Erase Data");
        EraseButton.setBounds(805, 530, 190, 50);
        EraseButton.setForeground(Color.RED);
        RegularGUIPanel.add(EraseButton);
        EraseButton.setFont(new Font("ui-monospaced",Font.BOLD,15));
        EraseButton.addActionListener(this);

        ///////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////

        // Dropout panel 1 containing title
        DropoutGUIPanel1=new JPanel();
        DropoutGUIPanel1.setLayout(null);
        DropoutGUIPanel1.setBackground(new Color(0,0,0,70));
        DropoutGUIPanel1.setBounds(0,0,1500,80);
        Checkout_Frame.add(DropoutGUIPanel1);
        DropoutGUIPanel1.setVisible(false);

        //overlay jlabel for text Dropout_Form
        JLabel DropoutLabel=new JLabel("Dropout_Form");
        DropoutLabel.setForeground(Color.BLACK);
        DropoutLabel.setBounds(459,20,500,40);
        DropoutLabel.setFont(new Font("ui-monospaced",Font.BOLD,30));
        DropoutGUIPanel1.add(DropoutLabel);

        DropoutGUIPanel=new JPanel();
        DropoutGUIPanel.setBounds(0, 0,1500, 900);
        DropoutGUIPanel.setLayout(null);
        DropoutGUIPanel.setBackground(Color.ORANGE);

        enrollmentIDLabel = new JLabel("Enrollment ID:");
        enrollmentIDLabel.setBounds(160, 150, 150, 40);
        DropoutGUIPanel.add(enrollmentIDLabel);
        enrollmentIDLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        enrollmentIDText1 = new JTextField();
        enrollmentIDText1.setBounds(350, 150, 200, 40);
        DropoutGUIPanel.add(enrollmentIDText1);
        enrollmentIDText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        courseNameLabel = new JLabel("Course Name:");
        courseNameLabel.setBounds(630, 150, 150, 40);
        DropoutGUIPanel.add(courseNameLabel);
        courseNameLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        courseNameText1 = new JTextField();
        courseNameText1.setBounds(800, 150, 200, 40);
        DropoutGUIPanel.add(courseNameText1);
        courseNameText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        studentNameLabel = new JLabel("Student Name:");
        studentNameLabel.setBounds(160, 200, 150, 40);
        DropoutGUIPanel.add(studentNameLabel);
        studentNameLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        studentNameText1 = new JTextField();
        studentNameText1.setBounds(350, 200, 200, 40);
        DropoutGUIPanel.add(studentNameText1);
        studentNameText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        dateOfBirthLabel = new JLabel("Date Of Birth:");
        dateOfBirthLabel.setBounds(630, 200, 100, 40);
        DropoutGUIPanel.add(dateOfBirthLabel);
        dateOfBirthLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        dateOfBirthComboBox1=new JComboBox<>();
        for(int i=1990; i< 2025; i++ )
        {
            dateOfBirthComboBox1.addItem(String.valueOf(i));            
        }
        dateOfBirthComboBox1.setBounds(800, 200, 200, 40);
        DropoutGUIPanel.add(dateOfBirthComboBox1);
        dateOfBirthComboBox1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        dateOfEnrollementLabel = new JLabel("Date Of Enrollement:");
        dateOfEnrollementLabel.setBounds(160, 250, 170, 40);
        DropoutGUIPanel.add(dateOfEnrollementLabel);
        dateOfEnrollementLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        dateOfEnrollementComboBox1= new JComboBox<>();
        for(int i=1995; i< 2025; i++)
        {
            dateOfEnrollementComboBox1.addItem(String.valueOf(i));
        }
        dateOfEnrollementComboBox1.setBounds(350, 250, 200, 40);
        DropoutGUIPanel.add(dateOfEnrollementComboBox1);
        dateOfEnrollementComboBox1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        courseDurationLabel = new JLabel("Course Duration:");
        courseDurationLabel.setBounds(630, 250, 150, 40);
        DropoutGUIPanel.add(courseDurationLabel);
        courseDurationLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        courseDurationText1 = new JTextField();
        courseDurationText1.setBounds(800, 250, 200, 40);
        DropoutGUIPanel.add(courseDurationText1);
        courseDurationText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        tuitionFeeLabel = new JLabel("Tuition Fee:");
        tuitionFeeLabel.setBounds(160, 300, 150, 40);
        DropoutGUIPanel.add(tuitionFeeLabel);
        tuitionFeeLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        tuitionFeeText1 = new JTextField();
        tuitionFeeText1.setBounds(350, 300, 200, 40);
        DropoutGUIPanel.add(tuitionFeeText1);
        tuitionFeeText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        numOfRemainingModulesLabel = new JLabel("Num.Of Remaining Modules:");
        numOfRemainingModulesLabel.setBounds(630, 300, 150, 40);
        DropoutGUIPanel.add(numOfRemainingModulesLabel);
        numOfRemainingModulesLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        numOfRemainingModulesText1 = new JTextField();
        numOfRemainingModulesText1.setBounds(800, 300, 200, 40);
        DropoutGUIPanel.add(numOfRemainingModulesText1);
        numOfRemainingModulesText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        numOfMonthsAttendedLabel = new JLabel("Num.Of Months Attended:");
        numOfMonthsAttendedLabel.setBounds(160, 350, 187, 40);
        DropoutGUIPanel.add(numOfMonthsAttendedLabel);
        numOfMonthsAttendedLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        numOfMonthsAttendedText1 = new JTextField();
        numOfMonthsAttendedText1.setBounds(350, 350, 200, 40);
        DropoutGUIPanel.add(numOfMonthsAttendedText1);
        numOfMonthsAttendedText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        dateOfDropoutLabel = new JLabel("Date Of Dropout:");
        dateOfDropoutLabel.setBounds(630, 350, 150, 40);
        DropoutGUIPanel.add(dateOfDropoutLabel);
        dateOfDropoutLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        dateOfDropoutComboBox1= new JComboBox<>();
        for(int i=1995; i<2025; i++)
        {
            dateOfDropoutComboBox1.addItem(String.valueOf(i));
        }
        dateOfDropoutComboBox1.setBounds(800, 350, 200, 40);
        DropoutGUIPanel.add(dateOfDropoutComboBox1);
        dateOfDropoutComboBox1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        remainingAmountLabel = new JLabel("Remaining Amount:");
        remainingAmountLabel.setBounds(160, 400, 187, 40);
        DropoutGUIPanel.add(remainingAmountLabel);
        remainingAmountLabel.setFont(new Font("ui-monospaced",Font.BOLD,15));

        remainingAmountText1 = new JTextField();
        remainingAmountText1.setBounds(350, 400, 200, 40);
        DropoutGUIPanel.add(remainingAmountText1);
        remainingAmountText1.setFont(new Font("ui-monospaced",Font.PLAIN,13));

        //Buttons////
        AddDropout=new JButton("Add an Object of Dropout");
        AddDropout.setBounds(350, 460, 450, 50);
        //AddDropout.setForeground(Color.BLACK);
        DropoutGUIPanel.add(AddDropout);
        AddDropout.setFont(new Font("ui-monospaced",Font.BOLD,18));
        AddDropout.addActionListener(this);

        //bills payable buttons
        billsPayableButton=new JButton("Bills Payable");
        billsPayableButton.setBounds(170, 530, 160, 50);
        //AddDropout.setForeground(Color.BLACK);
        DropoutGUIPanel.add(billsPayableButton);
        billsPayableButton.setFont(new Font("ui-monospaced",Font.BOLD,18));
        billsPayableButton.addActionListener(this);

        //remove button
        RemoveButton=new JButton("Remove");
        RemoveButton.setBounds(350, 530, 190, 50);
        //AddDropout.setForeground(Color.BLACK);
        DropoutGUIPanel.add(RemoveButton);
        RemoveButton.setFont(new Font("ui-monospaced",Font.BOLD,18));
        RemoveButton.addActionListener(this);

        //display button
        DisplayButton1=new JButton("Display");
        DisplayButton1.setBounds(590, 530, 190, 50);
        //AddDropout.setForeground(Color.BLACK);
        DropoutGUIPanel.add(DisplayButton1);
        DisplayButton1.setFont(new Font("ui-monospaced",Font.BOLD,18));
        DisplayButton1.addActionListener(this);

        //EraseButton 
        EraseButton1=new JButton("Erase Data");
        EraseButton1.setBounds(805, 530, 190, 50);
        EraseButton1.setForeground(Color.RED);
        DropoutGUIPanel.add(EraseButton1);
        EraseButton1.setFont(new Font("ui-monospaced",Font.BOLD,18));
        EraseButton1.addActionListener(this);

        RegularGUIPanel.setVisible(false);
        DropoutGUIPanel.setVisible(false);
        Checkout_Frame.add(DropoutGUIPanel);
        Checkout_Frame.add(RegularGUIPanel);
        Checkout_Frame.setVisible(true);

    }

    public void regularSee()
    {
        RegularGUIPanel.setVisible(true);
        RegularGUIPanel1.setVisible(true);
    }

    public void dropoutSee()
    {
        DropoutGUIPanel.setVisible(true); 
        DropoutGUIPanel1.setVisible(true);
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////   Regular and Dropout  //////////////////////////////////

    ///Regular ActionEvent e
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==AddRegular)
        {
            this.getRegularData();
            if(enrollmentID<=0 || dateOfBirth.isEmpty()||courseName.isEmpty()||studentName.isEmpty()||dateOfEnrollement.isEmpty()||courseDuration<=0||tuitionFee<=0||numOfModules<=0||numOfCreditHours<=0||daysPresent<0)
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"Please, fill all textfields. "); 
            }
            else
            {
                for(Student s: StudentList)
                {
                    if(s instanceof Regular)
                    {
                        Regular r=(Regular)s;
                        if(r.getenrollmentID()==enrollmentID)
                        {
                            JOptionPane.showMessageDialog(Checkout_Frame,"object with enrollmentID already exist"); 
                            return;
                        }
                    }
                }
                Regular r=new Regular(enrollmentID,dateOfBirth,courseName,studentName,dateOfEnrollement,courseDuration,tuitionFee,numOfModules,numOfCreditHours,daysPresent);
                StudentList.add(r);
                JOptionPane.showMessageDialog(Checkout_Frame,"Object Created Successfully"); 
            }

        }

        if(e.getSource()==presentPercentageButton)
        {

            if(StudentList.isEmpty())
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"No object created");
            }
            else
            {
                boolean loopforid=true;
                while(loopforid==true)
                {
                    boolean enrollId=false;
                    int SID=Integer.parseInt(JOptionPane.showInputDialog(Checkout_Frame ,"Enter your enrollment ID"));

                    for (Student R:StudentList)
                    {
                        if(R instanceof Regular)
                        {
                            Regular r=(Regular)R;
                            if(SID==r.getenrollmentID())
                            {
                                double Presentdays=Double.parseDouble(JOptionPane.showInputDialog(Checkout_Frame ,"Enter number of days Present"));
                                if(Presentdays<(r.getcourseDuration())*30)
                                {
                                    char Grade=r.presentPercentage(Presentdays);
                                    JOptionPane.showMessageDialog(Checkout_Frame,"Present Percentage Successfully \n"+"Grade is "+Grade);

                                }
                                else
                                {
                                    JOptionPane.showMessageDialog(Checkout_Frame,"Error : "+"You gave the days present "+Presentdays+ " more than course duration : "+(r.getcourseDuration()*30)); 
                                }
                                enrollId=false;
                                loopforid=false;
                                break;
                            }
                            else
                            {
                                enrollId=true;
                                //JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                                loopforid=true;
                            }

                        }
                    }
                    if(enrollId)
                    {
                        JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                    }
                }
            }

        }

        if(e.getSource()==grantCertificateButton)
        {
            if(StudentList.isEmpty())
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"No object created");
            }
            else
            { 
                boolean loopforid=true;
                while(loopforid)
                {
                    boolean enrollId=false;
                    int SID=Integer.parseInt(JOptionPane.showInputDialog(Checkout_Frame ,"Enter your enrollment ID"));
                    for (Student R:StudentList)
                    {
                        if(R instanceof Regular)
                        {
                            Regular r=(Regular)R;
                            if(SID==r.getenrollmentID())
                            {
                                JComboBox<String> dateOfEnrollementComboboxx=new JComboBox<>();
                                for(int X=1995; X< 2025; X++)
                                {
                                    dateOfEnrollementComboboxx.addItem(String.valueOf(X));
                                }
                                JOptionPane.showMessageDialog(Checkout_Frame ,dateOfEnrollementComboboxx,"Select date of enrollment",JOptionPane.QUESTION_MESSAGE);
                                //coursename
                                String CourseName=JOptionPane.showInputDialog(Checkout_Frame ,"Enter the Course Name");
                                String doe= String.valueOf(dateOfEnrollementComboboxx.getSelectedItem());
                                r.grantCertificate(CourseName,SID, doe);
                                JOptionPane.showMessageDialog(Checkout_Frame,"Your Grant Certificate is Successfully");
                                enrollId=false;
                                loopforid=false;
                                break;
                            }
                            else
                            {
                                enrollId=true;
                                loopforid=true;
                            }
                        }
                    }
                    if(enrollId){
                        JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                    }
                }

            }
        }

        if(e.getSource()==DisplayButton)
        {
            if(StudentList.isEmpty())
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"No object created");
            }
            else
            {
                boolean loopforid=true;
                while(loopforid)
                {
                    boolean enrollId=false;
                    int SID=Integer.parseInt(JOptionPane.showInputDialog(Checkout_Frame ,"Enter your enrollment ID"));
                    for(Student R:StudentList)
                    {
                        if(R instanceof Regular)
                        {
                            Regular r=(Regular)R;
                            if(SID==r.getenrollmentID())
                            {
                                r.display();
                                JOptionPane.showMessageDialog(Checkout_Frame,"Object of all Attributes are shown Successfully");
                                enrollId=false;
                                loopforid=false;
                                break;
                            }
                            else
                            {
                                //JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not Matched");
                                enrollId=true;
                                loopforid=true;
                            }
                        }
                    }
                    if(enrollId){
                        JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                    }

                }
            }
        }

        //ClearButton of RegularGUI
        if(e.getSource()==EraseButton)
        {
            studentNameText.setText(""); 
            enrollmentIDText.setText("");
            courseNameText.setText("");
            courseDurationText.setText("");
            tuitionFeeText.setText("");
            numOfModulesText.setText("");
            numOfCreditHoursText.setText("");
            daysPresentText.setText("");
            dateOfBirthComboBox.setSelectedIndex(-1);
            dateOfEnrollementComboBox.setSelectedIndex(-1);

        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        if(e.getSource()==AddDropout)
        {
            this.getDropoutData();
            if(studentName.isEmpty() || enrollmentID<=0 || courseName.isEmpty() || courseDuration<=0 || tuitionFee<=0||numOfRemainingModules<0|| numOfMonthsAttended<=0)
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"Please, fill all the textfield");
            }
            else
            {
                for(Student s:StudentList)
                {
                    if(s instanceof Dropout)
                    {
                        Dropout d=(Dropout)s;
                        if(d.getenrollmentID()==enrollmentID)
                        {
                            JOptionPane.showMessageDialog(Checkout_Frame,"Object with enrollmentID is already exist");
                            return;
                        }
                    }
                }
                Dropout d=new Dropout(enrollmentID,courseName,dateOfEnrollement,dateOfBirth,studentName,courseDuration,tuitionFee,numOfRemainingModules,numOfMonthsAttended,dateOfDropout);
                StudentList.add(d);
                JOptionPane.showMessageDialog(Checkout_Frame,"Object Created Successfully");
            }

        }

        if(e.getSource()==billsPayableButton)
        {
            if(StudentList.isEmpty())
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"No object created");
            }
            else
            {
                boolean loopforid=true;
                while(loopforid)
                {
                    boolean enrollId=false;
                    int SID=Integer.parseInt(JOptionPane.showInputDialog(Checkout_Frame ,"Enter your enrollment ID"));

                    for (Student D:StudentList)
                    {
                        if(D instanceof Dropout)
                        {
                            Dropout d=(Dropout)D;
                            if(SID==d.getenrollmentID())
                            {
                                d.billsPayable();
                                JOptionPane.showMessageDialog(Checkout_Frame,"Bills is Cleared Successfully.So the remaining Amount is : " +d.getremainingAmount());
                                enrollId=false;
                                loopforid=false;
                                break;
                            }
                            else
                            {
                                enrollId=true;
                                loopforid=true;

                            }
                        }
                    }
                    if(enrollId){
                        JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                    }
                }
            }
        }

        if(e.getSource()==RemoveButton)
        {
            if(StudentList.isEmpty())
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"No object created");
            }
            else
            {
                boolean loopforid=true;
                while(loopforid)
                {
                    boolean enrollId=false;
                    int SID=Integer.parseInt(JOptionPane.showInputDialog(Checkout_Frame ,"Enter your enrollment ID"));
                    for (Student D:StudentList)
                    {
                        if(D instanceof Dropout)
                        {
                            Dropout d=(Dropout)D;
                            if(SID==d.getenrollmentID())
                            {
                                if(d.gethasPaid())
                                {
                                    d. removeStudent();
                                    JOptionPane.showMessageDialog(Checkout_Frame,"Student is Removed Successfully");
                                }
                                else
                                {
                                    JOptionPane.showMessageDialog(Checkout_Frame,"Dues are not Cleared, So Student mey not able to Remove"); 
                                }
                                enrollId=false;
                                loopforid=false;
                                break;
                            }
                            else
                            {
                                enrollId=true;
                                loopforid=true;
                            }
                        }
                    }
                    if(enrollId){
                        JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                    }

                }
            }
        }

        //DisplayButton of DropoutGUI. 
        if(e.getSource()==DisplayButton1)
        {
            if(StudentList.isEmpty())
            {
                JOptionPane.showMessageDialog(Checkout_Frame,"No object created");
            }
            else
            {
                boolean whileloop=true;
                while(whileloop)
                {
                    boolean enrollId=false;
                    int SID=Integer.parseInt(JOptionPane.showInputDialog(Checkout_Frame ,"Enter your enrollment ID"));
                    for(Student D:StudentList)
                    {
                        if(D instanceof Dropout)
                        {
                            Dropout d=(Dropout)D;
                            if(SID==d.getenrollmentID())
                            {
                                d.display();
                                JOptionPane.showMessageDialog(Checkout_Frame,"Object of all Attributes are shown Successfully");
                                enrollId=false;
                                whileloop=false;
                                break;
                            }
                            else
                            {
                                //JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not Matched");
                                enrollId=true;
                                whileloop=true;
                            }
                        }
                    }
                    if(enrollId){
                        JOptionPane.showMessageDialog(Checkout_Frame,"Your Enrollment ID is not found");
                    }
                }
            }
        }

        if(e.getSource()==EraseButton1)
        {
            studentNameText1.setText(""); 
            enrollmentIDText1.setText("");
            courseNameText1.setText("");
            courseDurationText1.setText("");
            tuitionFeeText1.setText("");
            numOfRemainingModulesText1.setText("");
            numOfMonthsAttendedText1.setText(""); 
            remainingAmountText1.setText("");
            dateOfBirthComboBox1.setSelectedIndex(-1);
            dateOfEnrollementComboBox1.setSelectedIndex(-1);
            dateOfDropoutComboBox1.setSelectedIndex(-1);
        }
    }

    public void getRegularData()
    {
        try 
        {
            this.enrollmentID=Integer.parseInt(enrollmentIDText.getText());        
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Id must be Integer" );
        }

        try 
        {
            this.dateOfBirth=String.valueOf(dateOfBirthComboBox.getSelectedItem());       
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Date of birth is null" );
        }

        try 
        {
            this.courseName=courseNameText.getText(); 
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Course name is Empty" );
        }

        try 
        {
            this.studentName=studentNameText.getText();    
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Student name is Empty" );
        }

        try 
        {
            this.dateOfEnrollement=String.valueOf(dateOfEnrollementComboBox.getSelectedItem());      
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Date of enrollement is null" );
        }

        try 
        {
            this.courseDuration=Integer.parseInt(courseDurationText.getText());      
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Course duration must be Integer" );
        }

        try 
        {
            this.tuitionFee=Integer.parseInt(tuitionFeeText.getText());     
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Tuition Fee must be Integer" );
        }

        try 
        {
            this. numOfModules=Integer.parseInt(numOfModulesText.getText());      
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Num Of Modules must be Integer" );
        }

        try 
        {
            this.numOfCreditHours=Integer.parseInt(numOfCreditHoursText.getText());      
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Num Of Credit Hours must be Integer" );
        }

        try 
        {
            this.daysPresent=Double.parseDouble(daysPresentText.getText());      
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Days Present must be Integer" );
        }

    }

    ///Drouout ActionEvent e 
    public void getDropoutData()
    {
        try 
        {
            this.enrollmentID=Integer.parseInt(enrollmentIDText1.getText());
            System.out.println(enrollmentID);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Id must be Integer" );
        }

        try 
        {
            this.dateOfBirth= String.valueOf(dateOfBirthComboBox1.getSelectedItem());
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Date of birth is null" );
        }

        try 
        {
            this.studentName=studentNameText1.getText();
            //System.out.println(studentName);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Student name is Empty" );
        }

        try 
        {
            this.courseName=courseNameText1.getText();
            //System.out.println(courseName);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Course name is Empty" );
        }

        try 
        {
            this.courseDuration=Integer.parseInt(courseDurationText1.getText());
            //System.out.println(courseDuration);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Course duration must be Integer" );
        }

        try 
        {
            this.tuitionFee=Integer.parseInt(tuitionFeeText1.getText());
            //System.out.println(tuitionFee);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Tuition Fee must be Integer" );
        }

        try 
        {
            this.numOfRemainingModules=Integer.parseInt(numOfRemainingModulesText1.getText());
            //System.out.println(numOfRemainingModules);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Num Of Remaining Modules must be Integer" );
        }

        try 
        {
            this.numOfMonthsAttended=Integer.parseInt(numOfMonthsAttendedText1.getText());
            //System.out.println(numOfMonthsAttended);
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Num Of Months Attended must be Integer" );
        }

        try 
        {
            this.dateOfDropout=String.valueOf(dateOfDropoutComboBox1.getSelectedItem());
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(Checkout_Frame,"Date Of Dropout is null" );
        }

    }

    public static void main(String[]agrs)
    {
        StudentGUI s=new StudentGUI();
    }
}
