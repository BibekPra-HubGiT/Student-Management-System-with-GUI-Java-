import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.Image;
import java.awt.Color;
import java.awt.Font;
import java.util.HashMap;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

/**
 * Write a description of class LoginGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LoginGUI implements ActionListener
{
    private JFrame loginframe;
    private JPanel loginpanel;
    private JPanel HeadingPanel;
    private JLabel background,background1;
    private JTextField textusername;
    private JPasswordField textpassword;
    private JButton logInButton;
    private JLabel userID,Password;
    private String ID,Pass;

    public LoginGUI()

    {
        
        //Frame
        loginframe=new JFrame();
        loginframe.setSize(850,550);
        loginframe.setLocation(300,100);
        loginframe.setLayout(null); 
        //font
        Font f=new Font("Serif",Font.BOLD,30);
        //Heading panel
        HeadingPanel=new JPanel();
        HeadingPanel.setBackground(new Color(0,0,0,100));
        HeadingPanel.setBounds(0,0,900,100);
        HeadingPanel.setLayout(null);

        //overlay jlabel for text login 
        JLabel name=new JLabel("Login-Page");
        name.setForeground(Color.BLUE);
        name.setBounds(325,25,200,40);
        name.setFont(f);
        HeadingPanel.add(name);

        //Main login panel
        loginpanel=new JPanel();
        loginpanel.setLayout(null);
        loginpanel.setSize(400,350);
        loginpanel.setBackground(new Color(0,0,0,100));
        loginpanel.setBounds(210,110,400,330);

        userID=new JLabel("User ID");
        userID.setBounds(50,10,100, 50);
        userID.setForeground(Color.WHITE);
        loginpanel.add(userID);
        userID.setFont(new Font("Arial", Font.BOLD, 20));

        //textfield for username
        textusername=new JTextField();
        textusername.setBounds(50,50,300,50);
        textusername.setFont(new Font("Arial", Font.PLAIN, 16));
        loginpanel.add(textusername);

        //textfield for Password
        Password=new JLabel("Password");
        Password.setBounds(50,100,200,50);
        Password.setForeground(Color.WHITE);
        loginpanel.add(Password);
        Password.setFont(new Font("Arial", Font.BOLD, 20));

        textpassword=new JPasswordField();
        textpassword.setBounds(50,150,300,50);
        loginpanel.add(textpassword);

        //Loginbutton
        logInButton=new JButton("Login");
        logInButton.addActionListener(this);
        logInButton.setForeground(Color.BLUE);
        logInButton.setBounds(150,250,100,50);
        loginpanel.add(logInButton);

         

        //Background image
        ImageIcon m=new ImageIcon("image_10.png");
        background= new JLabel("",m,JLabel.CENTER);
        Image img=m.getImage();
        Image temp=img.getScaledInstance(900,600,Image.SCALE_SMOOTH);
        m=new ImageIcon(temp);

        background.add(loginpanel);
        background.add(HeadingPanel);
        background.setBounds(0,0,860,570);
        loginframe.add(background);
        loginframe.setVisible(true);
        loginframe.setResizable(false);
    }

    public void checkIDPass()
    {
        HashMap<String, String> loginIdpass = new HashMap<String, String>();
        loginIdpass .put("Regular", "regular12");
        loginIdpass .put("Dropout", "dropout12");
        this.ID=textusername.getText();
        char[] ps=textpassword.getPassword();
        String password=new String(ps);
        this.Pass=password;

        if(loginIdpass.containsKey(ID))
        {
            if(ID.equals("Regular"))
            {
                if (loginIdpass .get(ID).equals(Pass))
                {
                    //JLabel message=new JLabel("Successful !");
                    //loginpanel.add(message);
                    StudentGUI s=new StudentGUI();
                    s.regularSee();

                    //loginframe.dispose();
                    textusername.setText("");
                    textpassword.setText("");

                }
                else
                {
                    JOptionPane.showMessageDialog(loginpanel,"password entered wrong");
                }
            }
            else if(ID.equals("Dropout"))
            {
                if (loginIdpass.get(ID).equals(Pass))
                {
                    JLabel message=new JLabel("Successful !");
                    loginpanel.add(message);
                    StudentGUI s=new StudentGUI();
                    s.dropoutSee();

                    //loginframe.dispose();
                    textusername.setText("");
                    textpassword.setText("");
                }
                else
                {
                    JOptionPane.showMessageDialog(loginpanel,"password entered wrong");
                }
            }
            else
            {
                JOptionPane.showMessageDialog(loginpanel,"username entered wrong");
            }

        }

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==logInButton)
        {
            this.checkIDPass();
        }
    }
    
    public static void main(String[] args)
    {
        LoginGUI log=new LoginGUI();
    }

}