
/**
 * Write a description of class Regular here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Regular extends Student
{
    //initalization variables
    private int numOfModules;
    private int numOfCreditHours;
    private double daysPresent;
    private boolean isGrantedScholarship;
    //constructor method
    public Regular(int enrollmentID,String dateOfBirth, String courseName, String studentName,String dateOfEnrollement,int courseDuration, int tuitionFee,int numOfModules,
    int numOfCreditHours,double daysPresent)
    {
        //call to parent class constructor method
        super(dateOfBirth,courseDuration,studentName,tuitionFee);
        //initialized variable of child class
        super.setcourseName(courseName);
        //call to parent class setter method
        super.setenrollmentID(enrollmentID);
        super.setdateOfEnrollement(dateOfEnrollement);
        this.numOfModules=numOfModules;
        this.numOfCreditHours=numOfCreditHours;
        this.daysPresent=daysPresent;
        this.isGrantedScholarship=false;
    }
    //accessor method is also called getter method.
    public int getnumOfModules()
    {
        return this.numOfModules;
    }

    public int getnumOfCreditHours()
    {
        return this.numOfCreditHours;
    }

    public double getdaysPresent()
    {
        return this.daysPresent;
    }

    public boolean getisGrantedScholarship()
    {
        return this.isGrantedScholarship;
    }
    //presentPercentage method is created
    public char presentPercentage(double daysPresent)
    {

        double presentPercentage;
        char attendanceGrade;
        presentPercentage=(daysPresent/(this.getcourseDuration()*30))*100;
        //this is used to check means daysPresent is valid or not.
        if ((this.getcourseDuration()*30) < daysPresent)
        {
            //in-case of invalid date i.e daysPresent is greater than course duration.
            System.out.println("Sorry Your data is invalid");
            return ' ';
        }  

        //grading system is set by attendanceGrade 
        if(presentPercentage>=80)
        {
            this.isGrantedScholarship=true;
            return attendanceGrade='A';
        }
        else if(presentPercentage>=60)
        {
            this.isGrantedScholarship=false;
            return attendanceGrade='B';
        }
        else if(presentPercentage>=40)
        {
            this.isGrantedScholarship=false;
            return attendanceGrade='C';
        }
        else if(presentPercentage>=20)
        {
            this.isGrantedScholarship=false;
            return attendanceGrade='D';
        }
        else
        {
            this.isGrantedScholarship=false;
            return attendanceGrade='E';
        }
    }
    //grantCertificate method is created
    public void grantCertificate(String courseName,int enrollmentID,String dateOfEnrollement)
    {
        super.setcourseName(courseName);
        super.setenrollmentID(enrollmentID);
        super.setdateOfEnrollement(dateOfEnrollement);
        System.out.println("A student is graduated");
        System.out.println("The_Student_course_Name_is"+this.getcourseName());
        System.out.println("The_Student_enrollmentId_is"+this.getenrollmentID());
        System.out.println("The_Student_date_Of_Enrollment_is"+this.getdateOfEnrollement());
        if(this.isGrantedScholarship) 
        {
            System.out.println("The scholarship has been granted.");
        }
    }
    //display method
    @Override
    public void display()
    {
        super.display();//call to parent class display method
        //Attributes or characters of child class 
        System.out.println("Your numOfModules "+this.getnumOfModules());
        System.out.println("Your numOfCreditHours "+this.getnumOfCreditHours());
        System.out.println("Your daysPresent "+this.getdaysPresent());
    }
}

